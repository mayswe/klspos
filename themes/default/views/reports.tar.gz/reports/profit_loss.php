<?php (defined('BASEPATH')) OR exit('No direct script access allowed'); ?>
<?php

// Monday of current week
$start_date = date('Y-m-d 00:00:00', strtotime('monday this week'));

// Saturday of current week
$end_date = date('Y-m-d 23:59:59', strtotime('saturday this week'));

?>
<section class="content">
    <div class="row">
        <div class="col-sm-12">
            <div class="box box-primary">
                <div class="box-header">
                    <a href="#" class="btn btn-default btn-sm toggle_form pull-right"><?= lang("show_hide"); ?></a>
                    <h4><?= $page_title; ?></h4>
                </div>
                <div class="box-body">
                    <div id="form" class="panel panel-warning">
                        <div class="panel-body">
                            <?= form_open("reports/profit_loss"); ?>
                            <div class="row">
                                <div class="col-sm-3">
                                    <label><?= lang("start_date"); ?></label>
                                    <?= form_input(
                                        'start_date',
                                        set_value('start_date', $start_date),
                                        'class="form-control datetimepicker" id="start_date"'
                                    ); ?>
                                </div>
                                <div class="col-sm-3">
                                    <label><?= lang("end_date"); ?></label>
                                    <?= form_input(
                                        'end_date',
                                        set_value('end_date', $end_date),
                                        'class="form-control datetimepicker" id="end_date"'
                                    ); ?>
                                </div>
                                <div class="col-sm-2">
                                    <br>
                                    <button type="submit" class="btn btn-primary"><?= lang("submit"); ?></button>
                                </div>
                            </div>
                            <?= form_close(); ?>
                        </div>
                    </div>

                    <div id="report-content"></div>
                </div>
            </div>
        </div>
    </div>
</section>

<script>
$(function () {
    function cf(num) {
        // Format number with commas and 2 decimals
        return Number(num).toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2});
    }

    function loadProfitLoss() {
        $.ajax({
            url: "<?= site_url('reports/get_profit_losss'); ?>",
            type: "POST",
            data: {
                start_date: $('#start_date').val(),
                end_date: $('#end_date').val(),
                "<?= $this->security->get_csrf_token_name(); ?>": "<?= $this->security->get_csrf_hash(); ?>"
            },
            success: function(res) {
                let data = JSON.parse(res);

                let html = `
                    <table class="table table-bordered" style="width:60%; margin:auto; text-align:right; border-collapse: collapse;">
                        <thead>
                            <tr style="background:#d9edf7; text-align:center;">
                                <th style="text-align:left; padding:8px;">အချက်အလက်</th>
                                <th style="padding:8px;">ပမာဏ (MMK)</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr style="background:#f9f9f9;"><td style="text-align:left; padding:8px;">အရောင်းဝင်ငွေ (Sales Revenue)</td><td>${cf(data.sales)}</td></tr>
                            <tr style="background:#ffffff;"><td style="text-align:left; padding:8px;">လျှော့ချခြင်း/ပြန်လည်အမ်းပေးခြင်း (Less: Discounts/Returns)</td><td>${cf(data.discounts)}</td></tr>
                            <tr style="background:#f9f9f9;"><td style="text-align:left; padding:8px;">အရောင်းသန့် (Net Sales)</td><td>${cf(data.net_sales)}</td></tr>
                            <tr style="background:#ffffff;"><td style="text-align:left; padding:8px;">ပစ္စည်းဝယ်ဈေး (COGS)</td><td>${cf(data.cogs)}</td></tr>
                            <tr style="background:#f9f9f9;"><td style="text-align:left; padding:8px;">အမြတ်အစွန်းမတိုင်မီ (Gross Profit)</td><td>${cf(data.gross_profit)}</td></tr>
                            <tr style="background:#ffffff;"><td style="text-align:left; padding:8px;">စီးပွားရေးစရိတ် (Operating Expenses)</td><td>${cf(data.operating_expenses)}</td></tr>
                            <tr style="background:#f9f9f9;"><td style="text-align:left; padding:8px;">ပစ္စည်းတန်ဖိုးကျဆင်းမှု (Depreciation)</td><td>${cf(data.depreciation)}</td></tr>
                            <tr style="background:#ffffff;"><td style="text-align:left; padding:8px;">စုစုပေါင်းစရိတ် (Total Expenses)</td><td>${cf(data.total_expenses)}</td></tr>
                            <tr style="background:#dff0d8; font-weight:bold;">
                                <td style="text-align:left; padding:8px;">အမြတ်သန့် (Net Profit)</td>
                                <td>${cf(data.net_profit)}</td>
                            </tr>
                        </tbody>
                    </table>
                `;
                $('#report-content').html(html);
            }
        });
    }

    loadProfitLoss();

    $('.datetimepicker').datetimepicker({format: 'YYYY-MM-DD HH:mm'});

    // Reload report when date changes
    $('#start_date, #end_date').on('change', loadProfitLoss);
});
</script>



<script src="<?= $assets ?>plugins/bootstrap-datetimepicker/js/moment.min.js" type="text/javascript"></script>
<script src="<?= $assets ?>plugins/bootstrap-datetimepicker/js/bootstrap-datetimepicker.min.js" type="text/javascript"></script>
<script type="text/javascript">
    $(function () {
        $('.datetimepicker').datetimepicker({
            format: 'YYYY-MM-DD HH:mm'
        });
        $('.datepicker').datetimepicker({format: 'YYYY-MM-DD', showClear: true, showClose: true, useCurrent: false, widgetPositioning: {horizontal: 'auto', vertical: 'bottom'}, widgetParent: $('.dataTable tfoot')});
    });
</script>



