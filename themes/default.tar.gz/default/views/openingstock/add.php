<?php (defined('BASEPATH')) or exit('No direct script access allowed'); ?>

<section class="content">
<div class="row">
<div class="col-xs-12">
<div class="box box-primary">
    <div class="box-header">
        <h4><?= $page_title ?? 'Opening Stock Entry'; ?></h4>
    </div>
    <div class="box-body">
        <div class="col-lg-12">
            <?= form_open('openingstock/add', 'class="validation" id="openingStockForm"'); ?>

            <table class="table table-bordered" id="openingStockTable">
                <thead>
                    <tr>
                        <th><button type="button" class="btn btn-success" id="addRow">+</button></th>
                        <th><?= lang('product'); ?></th>
                        <th><?= lang('quantity_base'); ?></th>
                        <th><?= lang('quantity_secondary'); ?></th>
                        <th><?= lang('location'); ?></th>
                        <th><?= lang('batch_no'); ?></th>
                        
                        <th><?= lang('cost_per_base'); ?></th>
                        
                    </tr>
                </thead>
                <tbody>
                    <!-- <tr>
                        <td>
                            <select name="product_id[]" class="form-control select2" required>
                                <option value=""><?= lang('select_product'); ?></option>
                                <?php foreach ($products as $p): ?>
                                    <option value="<?= $p->id ?>"><?= $p->name ?></option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                        <td>
                            <select name="store_id[]" class="form-control select2">
                                <option value=""><?= lang('select_location'); ?></option>
                                <?php foreach ($stores as $w): ?>
                                    <option value="<?= $w->id ?>"><?= $w->name ?></option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                        
                        <td><input type="text" name="batch_no[]" class="form-control"></td>
                        <td><input type="number" step="0.000001" name="qty_base[]" class="form-control" required></td>
                        <td><input type="number" step="0.000001" name="qty_secondary[]" class="form-control" value="0"></td>
                        <td><input type="number" step="0.000001" name="cost_per_base[]" class="form-control"></td>
                        <td><button type="button" class="btn btn-danger removeRow">-</button></td>
                    </tr> -->
                    <tr>
                        <td><button type="button" class="btn btn-danger removeRow">-</button></td>
    <td>
        <select name="product_id[]" class="form-control select2" required>
            <option value=""><?= lang('select_product'); ?></option>
            <?php foreach ($products as $p): ?>
                <option value="<?= $p->id ?>"><?= $p->name ?></option>
            <?php endforeach; ?>
        </select>
    </td>
    <td><input type="number" step="0.000001" name="qty_base[]" class="form-control" required></td>
    <td><input type="number" step="0.000001" name="qty_secondary[]" class="form-control" value="0"></td>
    <td>
        <select name="store_id[]" class="form-control select2">
            <option value=""><?= lang('select_location'); ?></option>
            <?php foreach ($stores as $w): ?>
                <option value="<?= $w->id ?>" <?= $w->id == 1 ? 'selected' : '' ?>><?= $w->name ?></option>
            <?php endforeach; ?>
        </select>
    </td>
    <td><input type="text" name="batch_no[]" class="form-control" value="Opening"></td>
    
    <td><input type="number" step="0.000001" name="cost_per_base[]" class="form-control" value=""></td>
    
</tr>

                </tbody>
            </table>

            <div class="form-group">
                <button type="submit" class="btn btn-primary"><?= lang('save_opening_stock'); ?></button>
                <a href="<?= site_url('openingstock'); ?>" class="btn btn-default"><?= lang('cancel'); ?></a>
            </div>

            <?= form_close(); ?>
        </div>
    </div>
</div>
</div>
</div>
</section>

<script>
$(document).ready(function(){
    // Add new row
    /* $('#addRow').click(function(){
        let newRow = $('#openingStockTable tbody tr:first').clone();

        // Clear values
        newRow.find('input').val('');
        newRow.find('input[type=number]').val(0);
        newRow.find('select').val('');

        // Remove select2 wrapper if exists
        newRow.find('.select2').removeClass("select2-hidden-accessible").next(".select2-container").remove();

        // Re-initialize select2
        newRow.find('select').select2();

        $('#openingStockTable tbody').append(newRow);
    }); */
    $('#addRow').click(function(){
    let newRow = $('#openingStockTable tbody tr:first').clone();

    // Only clear product and quantities
    newRow.find('select[name="product_id[]"]').val('');
    newRow.find('input[name="qty_base[]"]').val('');
    newRow.find('input[name="qty_secondary[]"]').val('0');

    // Keep default store, batch no, cost
    newRow.find('select[name="store_id[]"]').val(1);
    newRow.find('input[name="batch_no[]"]').val('Opening');
    newRow.find('input[name="cost_per_base[]"]').val('');

    // Remove old select2 and re-initialize
    newRow.find('.select2').removeClass("select2-hidden-accessible").next(".select2-container").remove();
    newRow.find('select').select2();

    $('#openingStockTable tbody').append(newRow);
});

    // Remove row
    $(document).on('click', '.removeRow', function(){
        if($('#openingStockTable tbody tr').length > 1){
            $(this).closest('tr').remove();
        }
    });
});

</script>
