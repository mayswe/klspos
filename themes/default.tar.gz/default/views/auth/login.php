<?php (defined('BASEPATH')) OR exit('No direct script access allowed'); ?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?= $page_title . ' | ' . $Settings->site_name; ?></title>
    <link rel="shortcut icon" href="<?= $assets ?>images/icon.png"/>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="<?= $assets ?>dist/css/styles.css" rel="stylesheet" type="text/css"/>
    <?= $Settings->rtl ? '<link href="' . $assets . 'dist/css/rtl.css" rel="stylesheet" />' : ''; ?>
    <style>
        body {
            background: #f5f7fa;
        }

        .login-box {
            width: 360px;
            margin: 7% auto;
            padding: 40px;
            background: #fff;
            box-shadow: 0 0 20px rgba(0,0,0,0.05);
            border-radius: 8px;
        }

        .login-logo img {
            max-width: 180px;
        }

        .google-btn {
            background: #dd4b39;
            color: white;
            padding: 12px;
            font-size: 16px;
            border: none;
            border-radius: 4px;
            display: block;
            width: 100%;
            text-align: center;
            transition: background 0.3s ease;
        }

        .google-btn:hover {
            background: #c23321;
            text-decoration: none;
            color: #fff;
        }

        .login-box-msg {
            font-size: 16px;
            margin-bottom: 20px;
            text-align: center;
            font-weight: bold;
        }
    </style>
</head>
<body class="login-page login-page-<?= $Settings->theme_style; ?> rtl rtl-inv">
<div class="login-box">
    <div class="login-logo">
        <a href="<?= base_url(); ?>">
            <?= $Settings->site_name == 'SimplePOS' ? 'Simple<b>POS</b>' : '<img src="' . base_url('uploads/' . $Settings->logo) . '" alt="' . $Settings->site_name . '" />'; ?>
        </a>
    </div>

    <div class="login-box-body">
        <?php if ($error) { ?>
            <div class="alert alert-danger"><?= $error; ?></div>
        <?php } if ($message) { ?>
            <div class="alert alert-success"><?= $message; ?></div>
        <?php } ?>

        <p class="login-box-msg">Sign in to continue</p>

        <a href="<?= base_url('auth/login_with_google'); ?>" class="google-btn">
            <i class="fa fa-google"></i> &nbsp;Login with Google
        </a>
    </div>
</div>

<script src="<?= $assets ?>plugins/jQuery/jQuery-2.1.4.min.js"></script>
<script src="<?= $assets ?>bootstrap/js/bootstrap.min.js"></script>
</body>
</html>
